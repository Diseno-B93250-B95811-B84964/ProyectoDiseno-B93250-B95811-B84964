/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author Mauricio Palma
 */
public class refereeStub {
    private String message;
    
    public refereeStub(){
        message = "";
    }
    
    public void setMessaage(String myMessage){
        this.message = myMessage; 
    }
    
    public String getMessage(){
        return this.message;
    }
}
